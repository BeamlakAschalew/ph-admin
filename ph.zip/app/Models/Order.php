<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Order extends Model {
    /** @use HasFactory<\Database\Factories\OrderFactory> */
    use HasFactory;

    protected $fillable = ['consumer_id', 'total_amount', 'status'];

    public function items() {
        return $this->hasMany(OrderItem::class);
    }

    public function customItems() {
        return $this->hasMany(CustomOrderItem::class);
    }

    public function consumer() {
        return $this->belongsTo(Consumer::class);
    }
}
